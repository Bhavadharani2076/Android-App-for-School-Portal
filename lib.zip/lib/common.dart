String ip= "http://172.23.26.15:80/project/";
String user="";