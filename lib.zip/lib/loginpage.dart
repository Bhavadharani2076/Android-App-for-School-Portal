import 'dart:convert'; // To decode JSON
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'Admin/Ahome.dart';
import 'Parent/Phome.dart';
import 'Staff/SThome.dart';
import 'Student/Shome.dart';
import 'common.dart'; // To handle HTTP requests

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  // Controllers for the input fields
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isLoading = false; // Loading indicator

  // Function to handle login
  Future<void> _login() async {
    setState(() {
      _isLoading = true;
    });

    String admissionNo = _usernameController.text.trim();
    String password = _passwordController.text.trim();

    if (admissionNo.isEmpty || password.isEmpty) {
      _showMessage('Username and password must not be empty');
      setState(() {
        _isLoading = false;
      });
      return;
    }

    // Create the API request
    final url = Uri.parse(ip + "login.php");

    // Debug print to check if we are hitting the API
    print("Sending request to: $url");

    final response = await http.post(url, body: {
      'admission_no': admissionNo,
      'password': password,
    });

    user = admissionNo;
    print(user);

    // Print response status code for debugging
    print("Response status code: ${response.statusCode}");

    if (response.statusCode == 200) {
      // Parse the response body
      final jsonResponse = jsonDecode(response.body);
      print("Response body: $jsonResponse");

      if (jsonResponse['status'] == 200) {
        String userType = jsonResponse['user_type'];

        // Navigate to the appropriate page based on user typeF
        if (userType == "Student") {
          Navigator.pushReplacement(
              context, MaterialPageRoute(builder: (context) => StdAttendance()));
        } else if (userType == "Parent") {
          Navigator.pushReplacement(
              context, MaterialPageRoute(builder: (context) => Pattendancesheet()));
        } else if (userType == "Faculty") {
          Navigator.pushReplacement(
              context, MaterialPageRoute(builder: (context) => staffattendance()));
        } else if (userType == "Admin") {
          Navigator.pushReplacement(
              context, MaterialPageRoute(builder: (context) => adminattendance()));
        } else {
          _showMessage('Invalid user type');
        }
      } else {
        _showMessage(jsonResponse['message']);
      }
    } else {
      _showMessage('Error: ${response.statusCode}');
    }

    setState(() {
      _isLoading = false;
    });
  }

  // Show a simple message dialog
  void _showMessage(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Message'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          // Background image
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/background.png'), // Path to your background image
                fit: BoxFit.cover,
              ),
            ),
          ),
          // Main content
          Center(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(16.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset('assets/logo.png', height: 120.0),
                  SizedBox(height: 20.0),
                  Text('KRP Matriculation', style: TextStyle(fontSize: 28.0, fontWeight: FontWeight.bold, color: Colors.white)),
                  Text('Higher Secondary School', style: TextStyle(fontSize: 16.0, color: Colors.white70)),
                  SizedBox(height: 30.0),
                  TextField(
                    controller: _usernameController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Username',
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.8),
                    ),
                  ),
                  SizedBox(height: 20.0),
                  TextField(
                    controller: _passwordController,
                    obscureText: true,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Password',
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.8),
                    ),
                  ),
                  SizedBox(height: 20.0),
                  ElevatedButton(
                    onPressed: _isLoading ? null : _login,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      padding: EdgeInsets.symmetric(horizontal: 100, vertical: 15),
                    ),
                    child: _isLoading
                        ? CircularProgressIndicator(color: Colors.white)
                        : Text('Sign In'),
                  ),
                  SizedBox(height: 15.0),
                  TextButton(
                    onPressed: () {
                      // Navigate to forgot password screen
                    },
                    child: Text('Forgot password?', style: TextStyle(color: Colors.white)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
}