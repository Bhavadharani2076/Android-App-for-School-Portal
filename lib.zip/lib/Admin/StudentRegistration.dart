import 'package:flutter/material.dart';
import 'package:flutter_file_dialog/flutter_file_dialog.dart';
import 'dart:io';

class StudentRegister extends StatefulWidget {
  @override
  _StudentRegisterState createState() => _StudentRegisterState();
}

class _StudentRegisterState extends State<StudentRegister> {
  // Controllers for text fields
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController contactController = TextEditingController();
  final TextEditingController classController = TextEditingController();
  final TextEditingController sectionController = TextEditingController();
  final TextEditingController dobController = TextEditingController();
  final TextEditingController bloodGroupController = TextEditingController();
  final TextEditingController addressLine1Controller = TextEditingController();
  final TextEditingController addressLine2Controller = TextEditingController();
  final TextEditingController cityController = TextEditingController();
  final TextEditingController stateController = TextEditingController();
  final TextEditingController countryController = TextEditingController();

  // Gender selection options
  String selectedGender = 'Select';
  final List<String> genderOptions = ['Select', 'Male', 'Female', 'Other'];

  // Profile image
  File? _image;

  Future<void> _pickImage() async {
    // Open a file dialog to pick an image
    final params = OpenFileDialogParams(
      dialogType: OpenFileDialogType.image,
      allowEditing: false,
    );

    final filePath = await FlutterFileDialog.pickFile(params: params);
    if (filePath != null) {
      setState(() {
        _image = File(filePath);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Row(
          children: [
            Image.asset(
              'assets/logo.png', // Replace with your logo asset path
              height: 40,
            ),
            SizedBox(width: 8),
            Text(
              'KRP',
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.notifications, color: Colors.black),
            onPressed: () {},
          ),
          IconButton(
            icon: CircleAvatar(
              backgroundImage: AssetImage('assets/student.png'), // Replace with your image URL
            ),
            onPressed: () {},
          ),
        ],
        automaticallyImplyLeading: false,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Text(
                'Student Registration Form',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.blueGrey,
                ),
              ),
            ),

            SizedBox(height: 20),
            // Profile Picture Section
            Center(
              child: GestureDetector(
                onTap: _pickImage,
                child: CircleAvatar(
                  radius: 50,
                  backgroundColor: Colors.grey[200],
                  backgroundImage: _image != null ? FileImage(_image!) : null,
                  child: _image == null
                      ? Icon(Icons.add_a_photo, size: 40, color: Colors.grey)
                      : null,
                ),
              ),
            ),

            SizedBox(height: 20),
            // Student Registration Form Heading

            // Student Name
            buildLabelText('Student Name:'),
            buildTextField('Name', nameController),
            SizedBox(height: 10),

            // Email
            buildLabelText('Email:'),
            buildTextField('Email', emailController),
            SizedBox(height: 10),

            // Contact Number
            buildLabelText('Contact Number :'),
            buildTextField('Contact Number', contactController),
            SizedBox(height: 10),

            // Class and Section
            Row(
              children: [
                Expanded(child: buildLabelText('Class:')),
                SizedBox(width: 20),
                Expanded(child: buildLabelText('Section:')),
              ],
            ),
            Row(
              children: [
                Expanded(child: buildTextField('Class', classController)),
                SizedBox(width: 20),
                Expanded(child: buildTextField('Section', sectionController)),
              ],
            ),
            SizedBox(height: 10),

            // Date of Birth
            buildLabelText('Date of Birth:'),
            buildTextField('dd/mm/yyyy', dobController),
            SizedBox(height: 10),

            // Gender Dropdown
            buildLabelText('Gender:'),
            buildDropdown(),

            SizedBox(height: 10),

            // Blood Group
            buildLabelText('Blood Group:'),
            buildTextField('Blood Group', bloodGroupController),
            SizedBox(height: 20),

            // Address Section
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey),
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 5,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Address',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.blueGrey,
                    ),
                  ),
                  SizedBox(height: 10),

                  // Address Line 1
                  buildTextField('Address Line 1', addressLine1Controller),
                  SizedBox(height: 10),

                  // Address Line 2
                  buildTextField('Address Line 2', addressLine2Controller),
                  SizedBox(height: 10),

                  // City, State, Country
                  Row(
                    children: [
                      Expanded(child: buildTextField('City', cityController)),
                      SizedBox(width: 10),
                      Expanded(child: buildTextField('State', stateController)),
                    ],
                  ),
                  SizedBox(height: 10),
                  buildTextField('Country', countryController),
                ],
              ),
            ),

            SizedBox(height: 20),

            // Submit Button
            Center(
              child: ElevatedButton(
                onPressed: () {
                  // Handle form submission
                  print('Form Submitted');
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  padding: EdgeInsets.symmetric(horizontal: 32.0, vertical: 12.0),
                ),
                child: Text(
                  'Submit',
                  style: TextStyle(color: Colors.white, fontSize: 16.0),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 0,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.menu),
            label: '',
          ),
        ],
      ),
    );
  }

  // Method to create input labels
  Widget buildLabelText(String text) {
    return Text(
      text,
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.bold,
        color: Colors.blueGrey,
      ),
    );
  }

  // Method to create a text field with controller
  Widget buildTextField(String hintText, TextEditingController controller) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        hintText: hintText,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        filled: true,
        fillColor: Colors.grey[100],
      ),
    );
  }

  // Method to create a dropdown for gender selection
  Widget buildDropdown() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            spreadRadius: 2,
            blurRadius: 5,
          ),
        ],
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          isExpanded: true,
          value: selectedGender,
          icon: Icon(Icons.arrow_drop_down),
          onChanged: (newValue) {
            setState(() {
              selectedGender = newValue!;
            });
          },
          items: genderOptions.map((String gender) {
            return DropdownMenuItem<String>(
              value: gender,
              child: Text(gender),
            );
          }).toList(),
        ),
      ),
    );
  }
}