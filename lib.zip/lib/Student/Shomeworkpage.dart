// import 'dart:convert';
// import 'dart:io';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'package:open_filex/open_filex.dart';
// import 'package:path_provider_android/path_provider_android.dart'; // Correct import
// import 'package:schoolportal/common.dart';
//
// class HomeworkPage extends StatefulWidget {
//   @override
//   _HomeworkPageState createState() => _HomeworkPageState();
// }
//
// class _HomeworkPageState extends State<HomeworkPage> {
//   List<dynamic> homeworkList = [];
//   bool isLoading = true;
//   String errorMessage = '';
//
//   @override
//   void initState() {
//     super.initState();
//     fetchHomework();
//   }
//
//   Future<void> fetchHomework() async {
//     try {
//       // Replace with your API endpoint
//       final response = await http.post(
//         Uri.parse(ip + 'student_get_homework.php'),
//         body: {'admission_number': user}, // Replace with the user's admission number
//       );
//       if (response.statusCode == 200) {
//         final data = json.decode(response.body);
//         if (data is List) {
//           setState(() {
//             homeworkList = data;
//             isLoading = false;
//           });
//         } else {
//           setState(() {
//             errorMessage = data['message'] ?? 'Failed to fetch homework.';
//             isLoading = false;
//           });
//         }
//       } else {
//         setState(() {
//           errorMessage = 'Error: ${response.reasonPhrase}';
//           isLoading = false;
//         });
//       }
//     } catch (e) {
//       setState(() {
//         errorMessage = 'Error fetching homework: $e';
//         isLoading = false;
//       });
//     }
//   }
//
//   Future<void> downloadAndOpenFile(String fileName) async {
//     try {
//       final url = ip + 'uploads/$fileName';
//       final response = await http.get(Uri.parse(url));
//       if (response.statusCode == 200) {
//         // Use PathProviderAndroid to get the directory
//         final pathProvider = PathProviderAndroid();
//         final directory = await pathProvider.getExternalStoragePath();
//         if (directory != null) {
//           final filePath = '$directory/$fileName';
//           final file = File(filePath);
//           await file.writeAsBytes(response.bodyBytes);
//           ScaffoldMessenger.of(context).showSnackBar(
//             SnackBar(content: Text('File downloaded to $filePath')),
//           );
//           OpenFilex.open(file.path);
//         } else {
//           throw Exception("Couldn't access external storage directory.");
//         }
//       } else {
//         ScaffoldMessenger.of(context).showSnackBar(
//           SnackBar(content: Text('Failed to download file: ${response.reasonPhrase}')),
//         );
//       }
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Error: $e')),
//       );
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Homework'),
//       ),
//       body: isLoading
//           ? Center(child: CircularProgressIndicator())
//           : errorMessage.isNotEmpty
//           ? Center(child: Text(errorMessage))
//           : ListView.builder(
//         itemCount: homeworkList.length,
//         itemBuilder: (context, index) {
//           final homework = homeworkList[index];
//           return Card(
//             margin: EdgeInsets.all(10),
//             child: Padding(
//               padding: const EdgeInsets.all(10.0),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     'Subject: ${homework['subject'] ?? "N/A"}',
//                     style: TextStyle(fontWeight: FontWeight.bold),
//                   ),
//                   Text('Class: ${homework['class'] ?? "N/A"}'),
//                   Text('Section: ${homework['section'] ?? "N/A"}'),
//                   Text('Description: ${homework['description'] ?? "N/A"}'),
//                   Text('Created Date: ${homework['date'] ?? "N/A"}'),
//                   Text('Submission Date: ${homework['last_date'] ?? "N/A"}'),
//                   SizedBox(height: 10),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                     children: [
//                       ElevatedButton(
//                         onPressed: () {
//                           if (homework['file'] != null) {
//                             downloadAndOpenFile(homework['file']);
//                           } else {
//                             ScaffoldMessenger.of(context).showSnackBar(
//                               SnackBar(content: Text('No file available to download.')),
//                             );
//                           }
//                         },
//                         child: Text('Download'),
//                       ),
//                       ElevatedButton(
//                         onPressed: () {
//                           // Implement 'View Homework' functionality here
//                           ScaffoldMessenger.of(context).showSnackBar(
//                             SnackBar(content: Text('View Homework button pressed')),
//                           );
//                         },
//                         child: Text('View'),
//                       ),
//                     ],
//                   ),
//                 ],
//               ),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }
