import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:schoolportal/common.dart';

class Examarkspage extends StatefulWidget {
  @override
  _ExamMarksPageState createState() => _ExamMarksPageState();
}

class _ExamMarksPageState extends State<Examarkspage> {
  bool isLoading = true;
  String errorMessage = '';
  List<Map<String, dynamic>> examData = [];

  Future<void> fetchExamMarks() async {
    final String registerNumber = user; // Replace with the actual register number
    final String url = ip + 'student_fetch_marks.php'; // Replace with your URL

    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'register_number': registerNumber}),
      );

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        if (responseData['status'] == 'success') {
          final data = responseData['data'];
          List<Map<String, dynamic>> processedData = [];
          for (var exam in data) {
            final examName = exam['exam_name'] ?? 'Unknown Exam';
            final totalGrade = exam['total_grade'] ?? 'N/A';
            final subjects = exam['subjects'] as Map<String, dynamic>;

            for (var subject in subjects.entries) {
              if (subject.key != 'register_number' &&
                  subject.key != 'name' &&
                  subject.key != 'total_grade') {
                processedData.add({
                  'exam_name': examName,
                  'subject': subject.key,
                  'marks': subject.value.toString(),
                  'total_grade': totalGrade,
                });
              }
            }
          }
          setState(() {
            examData = processedData;
            isLoading = false;
          });
        } else {
          setState(() {
            errorMessage = responseData['message'] ?? 'Unknown error occurred';
            isLoading = false;
          });
        }
      } else {
        setState(() {
          errorMessage = 'Failed to load data (HTTP ${response.statusCode})';
          isLoading = false;
        });
      }
    } catch (error) {
      setState(() {
        errorMessage = 'An error occurred: $error';
        isLoading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchExamMarks();
  }

  @override
  Widget build(BuildContext context) {
    // Group examData by exam_name to display Total Grade once per exam
    Map<String, List<Map<String, dynamic>>> groupedData = {};
    for (var item in examData) {
      final examName = item['exam_name'];
      if (!groupedData.containsKey(examName)) {
        groupedData[examName] = [];
      }
      groupedData[examName]?.add(item);
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Exam Marks'),
        backgroundColor: Colors.green,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : errorMessage.isNotEmpty
          ? Center(
        child: Text(
          errorMessage,
          style: const TextStyle(color: Colors.red, fontSize: 18),
          textAlign: TextAlign.center,
        ),
      )
          : ListView.builder(
        itemCount: groupedData.length,
        itemBuilder: (context, index) {
          String examName =
          groupedData.keys.elementAt(index); // Get exam name
          List<Map<String, dynamic>> subjects =
          groupedData[examName]!;

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Top Section with Total Grade
              Card(
                margin: const EdgeInsets.symmetric(
                    vertical: 8, horizontal: 16),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    'Total Grade: ${subjects.first['total_grade']}',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.green,
                    ),
                  ),
                ),
              ),
              // Subjects Section
              ...subjects.map((subject) {
                return Card(
                  margin: const EdgeInsets.symmetric(
                      vertical: 4, horizontal: 16),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      mainAxisAlignment:
                      MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            'Exam: ${subject['exam_name']}',
                            style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        Expanded(
                          child: Text(
                            'Subject: ${subject['subject']}',
                            style: const TextStyle(fontSize: 16),
                          ),
                        ),
                        Text(
                          'Marks: ${subject['marks']}',
                          style: const TextStyle(fontSize: 16),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ],
          );
        },
      ),
    );
  }
}
